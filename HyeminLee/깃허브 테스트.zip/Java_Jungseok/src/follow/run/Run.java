package follow.run;

import follow.exam.Break_Ex;
import follow.exam.While_Ex;

public class Run {

	public static void main(String[] args) {
	

		
		While_Ex a = new While_Ex();
		Break_Ex b = new Break_Ex();
		
		
		
//		a.Ex4_12();
//		a.Ex4_13();
//		a.Ex4_14();
//		a.Ex4_15();
		

		
		b.Ex4_19();
		
		
	}

		
		
		
		


}
