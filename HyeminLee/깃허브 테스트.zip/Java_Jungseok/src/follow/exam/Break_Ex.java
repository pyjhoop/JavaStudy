package follow.exam;

public class Break_Ex {

	public void Ex4_19() {
		
		
		Loop1 : for (int i=2; i<=9; i++) {  // 곱하기 코드   @ * # 중에 @를 담당 -> @만큼 더해져야함
				for (int j=1; j<=9; j++) {	//	@ * # 중에 #를 담당  -> 1씩 더해지면서 곱하기
					
					if (j==5)
						break Loop1;		// 2번 탈출구
//						break;  			// 1번 탈출구
					
					
//						continue Loop1;    // continue는 가능하나 실사용이 거의 없어서 된다고만 알아두면 됨
//						continue;
						
						System.out.println(i + " * " + j + " = " + (i*j));
						
	
				}  // 1번 break 탈출구  -> 모든 구구단이 4단까지만 실행하게 됨 
//				 			2단 ~ 
//						9 * 1 = 9
//						9 * 2 = 18
//						9 * 3 = 27
//						9 * 4 = 36

				
			
			System.out.println();
			
		}	//break Loop1;  2번 탈출구 / for문 전체 벗어남 -> 2단만 실행
	
	
		
	}

	
}
